# FOXVPN — Android проект

Это исходный проект Android-клиента WireGuard, а не готовый APK. Клиент использует официальную библиотеку `com.wireguard.android:tunnel` и её userspace backend `GoBackend`.

## Что нужно для настоящего подключения

1. Арендуйте/разверните собственный WireGuard-сервер или получите конфигурацию от VPN-провайдера.
2. Получите клиентский файл `.conf` (с `[Interface]`, `[Peer]`, `PrivateKey`, `Address`, `PublicKey`, `Endpoint`, `AllowedIPs` и при необходимости `DNS`).
3. В приложении FOXVPN нажмите **ИМПОРТ .CONF**, выберите файл, затем нажмите **ПОДКЛЮЧИТЬСЯ**.
4. Android покажет системный запрос на разрешение VPN — подтвердите его.

Без действующего сервера и корректного `.conf` подключение не заработает. В проект намеренно не встроены публичные чужие серверы и вымышленные ключи.

## Сборка APK

Требуется Android Studio (или Android SDK + JDK 17) и интернет для загрузки Gradle/Maven-зависимостей.

1. Откройте папку `FOXVPN-Android` в Android Studio.
2. Дождитесь Gradle Sync.
3. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Для релизной версии настройте собственную подпись в Android Studio: **Build → Generate Signed Bundle / APK**.

## Технические замечания

- Протокол: WireGuard.
- Минимальная версия Android: API 26 (Android 8.0).
- Конфигурация хранится в приватных SharedPreferences приложения. Перед публикацией добавьте шифрование конфигурации Android Keystore, безопасное удаление, обработку жизненного цикла туннеля, проверку DNS/leak protection и полноценные тесты.
- Этот стартовый проект не содержит панели управления пользователями, биллинга, списка локаций или VPN-инфраструктуры.
- Kill Switch не включён автоматически: его нужно отдельно настроить через системные настройки Android «Блокировать соединения без VPN» после проверки стабильности клиента.

## Ссылки

- WireGuard embedding: https://www.wireguard.com/embedding/
- Android VPN guide: https://developer.android.com/develop/connectivity/vpn
- WireGuard tunnel artifact: https://central.sonatype.com/artifact/com.wireguard.android/tunnel
