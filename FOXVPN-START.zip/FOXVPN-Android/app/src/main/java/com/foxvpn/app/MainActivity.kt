package com.foxvpn.app

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream

private val Bg = Color(0xFF080B14)
private val Panel = Color(0xFF121827)
private val Purple = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF32D6D0)

class MainActivity : ComponentActivity() {
    private lateinit var backend: GoBackend
    private val tunnel = object : Tunnel {
        override fun getName() = "FOXVPN"
        override fun onStateChange(newState: Tunnel.State) {}
    }
    private var configText by mutableStateOf("")
    private var connected by mutableStateOf(false)
    private var status by mutableStateOf("Импортируйте конфигурацию WireGuard")
    private var busy by mutableStateOf(false)

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) connectNow() else status = "Разрешение VPN не выдано"
    }
    private val configPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    configText = stream.bufferedReader().readText()
                    getSharedPreferences("foxvpn", MODE_PRIVATE).edit().putString("wg_config", configText).apply()
                    status = "Конфигурация загружена. Можно подключаться."
                } ?: run { status = "Не удалось прочитать файл" }
            } catch (e: Exception) { status = "Ошибка чтения: ${e.message}" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)
        configText = getSharedPreferences("foxvpn", MODE_PRIVATE).getString("wg_config", "") ?: ""
        if (configText.isNotBlank()) status = "Конфигурация готова"
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple, secondary = Cyan, background = Bg, surface = Panel
            )) {
                FoxVpnScreen(
                    connected = connected, status = status, busy = busy,
                    hasConfig = configText.isNotBlank(),
                    onConnect = { requestConnect() },
                    onDisconnect = { disconnectNow() },
                    onImport = { configPicker.launch(arrayOf("text/*", "application/octet-stream")) }
                )
            }
        }
    }

    private fun requestConnect() {
        if (configText.isBlank()) {
            status = "Сначала импортируйте .conf от VPN-сервера"
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else connectNow()
    }

    private fun connectNow() {
        busy = true
        status = "Подключение к серверу…"
        Thread {
            try {
                val config = Config.parse(ByteArrayInputStream(configText.toByteArray(Charsets.UTF_8)))
                backend.setState(tunnel, Tunnel.State.UP, config)
                runOnUiThread {
                    connected = true
                    busy = false
                    status = "Туннель WireGuard активен"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    connected = false
                    busy = false
                    status = "Не удалось подключиться: ${e.message ?: "проверьте конфигурацию и сервер"}"
                }
            }
        }.start()
    }

    private fun disconnectNow() {
        busy = true
        Thread {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
                runOnUiThread {
                    connected = false
                    busy = false
                    status = "Отключено"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    busy = false
                    status = "Ошибка отключения: ${e.message}"
                }
            }
        }.start()
    }
}

@Composable
private fun FoxVpnScreen(
    connected: Boolean, status: String, busy: Boolean, hasConfig: Boolean,
    onConnect: () -> Unit, onDisconnect: () -> Unit, onImport: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(42.dp).background(
                        Brush.linearGradient(listOf(Purple, Cyan)), RoundedCornerShape(14.dp)
                    ), contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Shield, null, tint = Color.White) }
                Spacer(Modifier.width(11.dp))
                Column {
                    Text("FOXVPN", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("PRIVATE CONNECTION", fontSize = 9.sp, color = Cyan, letterSpacing = 2.sp)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.Settings, "Настройки", tint = Color.LightGray)
            }
            Spacer(Modifier.height(48.dp))
            Text(if (connected) "ЗАЩИЩЕНО" else "ВАШ ИНТЕРНЕТ", color = Color.LightGray, letterSpacing = 3.sp, fontSize = 11.sp)
            Spacer(Modifier.height(24.dp))
            Box(
                modifier = Modifier.size(224.dp)
                    .background(Color(0xFF111A2B), CircleShape)
                    .border(1.dp, if (connected) Cyan else Purple.copy(alpha = .65f), CircleShape)
                    .padding(17.dp)
                    .background(Color(0xFF17243A), CircleShape)
                    .border(1.dp, Color.White.copy(alpha = .07f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier.size(145.dp)
                        .background(
                            Brush.linearGradient(if (connected) listOf(Cyan, Purple) else listOf(Purple, Color(0xFF4C3A9C))),
                            CircleShape
                        ), contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(68.dp))
                }
            }
            Spacer(Modifier.height(25.dp))
            Text(if (connected) "Подключено" else "Не подключено", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(status, color = Color(0xFF9AA7BD), fontSize = 12.sp, lineHeight = 18.sp)
            Spacer(Modifier.height(28.dp))
            Button(
                onClick = { if (connected) onDisconnect() else onConnect() },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (connected) Color(0xFF263449) else Purple)
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                else Text(if (connected) "ОТКЛЮЧИТЬСЯ" else "ПОДКЛЮЧИТЬСЯ", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(14.dp))
            OutlinedButton(
                onClick = onImport,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF39445A))
            ) {
                Icon(Icons.Default.UploadFile, null, tint = Cyan)
                Spacer(Modifier.width(9.dp))
                Text(if (hasConfig) "ЗАМЕНИТЬ КОНФИГУРАЦИЮ" else "ИМПОРТ .CONF", color = Color.White)
            }
            Spacer(Modifier.weight(1f))
            Row(
                modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Lock, null, tint = Cyan)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("WIREGUARD", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Современный VPN-протокол", color = Color(0xFF9AA7BD), fontSize = 11.sp)
                }
                Spacer(Modifier.weight(1f))
                Text(if (hasConfig) "ГОТОВО" else "НЕТ СЕРВЕРА", color = if (hasConfig) Cyan else Color(0xFFFFB86B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Text("FOXVPN • Ваше соединение под контролем", color = Color(0xFF64718A), fontSize = 10.sp)
        }
    }
}
